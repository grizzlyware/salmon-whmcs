<?php

// Load composer, which will load the Salmon autoloaders, to load the classes as they're used
require __DIR__ . DIRECTORY_SEPARATOR . "vendor" . DIRECTORY_SEPARATOR . "autoload.php";

